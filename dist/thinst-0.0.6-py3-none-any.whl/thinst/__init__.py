__all__ = ['thinst']

from .core import thinst
